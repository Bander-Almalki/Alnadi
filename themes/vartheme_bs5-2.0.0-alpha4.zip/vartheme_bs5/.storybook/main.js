// .storybook/main.js

module.exports = {
  staticDirs: [{ from: '../images', to: '/assets' }],
};
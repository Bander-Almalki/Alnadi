// .storybook/manager.js
import '@storybook/addon-viewport/register';
import '@storybook/addon-actions/register';
// import '@storybook/addon-knobs/dist/register';
import '@storybook/addon-links/register';
import '@storybook/addon-backgrounds/register';
// import '@storybook/addon-storysource/register';
import '@storybook/addon-docs/register';
import '@storybook/addon-a11y/register';
import '@storybook/addon-controls/register';
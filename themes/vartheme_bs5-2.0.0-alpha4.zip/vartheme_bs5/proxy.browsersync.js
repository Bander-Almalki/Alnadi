const proxy = 'http://varbase.local';

module.exports = {
	proxy: proxy,
};

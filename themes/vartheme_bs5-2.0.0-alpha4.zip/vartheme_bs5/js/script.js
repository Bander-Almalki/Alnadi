(function () {
  // Your js here
})();

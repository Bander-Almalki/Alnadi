DEFAULT INSTALL SETTINGS
----------------------------------

Before installing your theme, change the name of STARTER.settings.yml to use
your theme name. This will ensure that base css and js are turned off by default on
install. You can add additional settings in that file if you need as well.

See zurb-foundation/config/install/zurb_foundation.settings.yml for example.
